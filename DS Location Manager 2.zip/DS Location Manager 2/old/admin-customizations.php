<?php
/**
 * Location Admin Customizations
 * Dashboard, menus, user profile fields, etc.
 */

if (!defined('ABSPATH')) {
    exit;
}

class DS_Location_Admin_Customizations {
    
    private $plugin;
    
    public function __construct($plugin) {
        $this->plugin = $plugin;
        
        add_action('admin_menu', array($this, 'customize_admin_menu'));
        add_action('show_user_profile', array($this, 'add_location_assignment_field'));
        add_action('edit_user_profile', array($this, 'add_location_assignment_field'));
        add_action('personal_options_update', array($this, 'save_location_assignment_field'));
        add_action('edit_user_profile_update', array($this, 'save_location_assignment_field'));
        add_action('admin_bar_menu', array($this, 'customize_admin_bar'), 999);
        add_filter('admin_footer_text', array($this, 'custom_admin_footer'));
        add_filter('manage_ds_location_posts_columns', array($this, 'location_posts_columns'));
        add_filter('manage_edit-ds_location_sortable_columns', array($this, 'location_sortable_columns'));
    }

    /**
     * Customize admin menu for location managers
     */
    public function customize_admin_menu() {
        $user = wp_get_current_user();
        if (!in_array('ds_location_manager', (array) $user->roles)) {
            return;
        }

        // Remove menu items
        $remove_menus = array(
            'edit-comments.php',
            'themes.php',
            'plugins.php',
            'tools.php',
            'options-general.php',
            'users.php',
            'edit.php?post_type=page'
        );

        foreach ($remove_menus as $menu) {
            remove_menu_page($menu);
        }

        global $menu;
        foreach ($menu as $key => $item) {
            if ($item[2] === 'edit.php') {
                $menu[$key][0] = 'My Posts';
            }
            if ($item[2] === 'edit.php?post_type=ds_location') {
                $menu[$key][0] = 'My Location';
            }
        }

        add_menu_page(
            'Location Dashboard',
            'Dashboard',
            'read',
            'ds-location-dashboard',
            array($this, 'location_dashboard_page'),
            'dashicons-dashboard',
            2
        );
    }

    /**
     * Location Manager Dashboard
     */
    public function location_dashboard_page() {
        $user = wp_get_current_user();
        $user_location_id = get_user_meta($user->ID, 'ds_assigned_location', true);
        if (!$user_location_id) {
            echo '<div class="wrap"><h1>No Location Assigned</h1><p>Please contact an administrator to assign you to a location.</p></div>';
            return;
        }

        $location = get_post($user_location_id);
        if (!$location) {
            echo '<div class="wrap"><h1>Assigned location not found</h1></div>';
            return;
        }

        // Get term id
        $term_id = 0;
        if (taxonomy_exists('ds_post_location')) {
            $term_id = $this->plugin->get_term_id_for_location($user_location_id);
        }

        $query_args = array(
            'post_type' => 'post',
            'posts_per_page' => 5,
        );
        if ($term_id) {
            $query_args['tax_query'] = array(array(
                'taxonomy' => 'ds_post_location',
                'field'    => 'term_id',
                'terms'    => array(intval($term_id))
            ));
        } else {
            $query_args['post__in'] = array(0);
        }

        $location_posts = get_posts($query_args);

        $my_posts_count = 0;
        if ($term_id) {
            $my_posts = get_posts(array(
                'post_type' => 'post',
                'posts_per_page' => -1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'ds_post_location',
                        'field' => 'term_id',
                        'terms' => $term_id
                    )
                ),
                'fields' => 'ids'
            ));
            $my_posts_count = count($my_posts);
        }

        ?>
        <div class="wrap">
            <h1>Location Dashboard</h1>

            <div class="ds-location-dashboard">
                <style>
                    .ds-location-dashboard { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px; }
                    .ds-dashboard-widget { background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); padding: 20px; }
                    .ds-dashboard-widget h3 { margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; }
                    .ds-stats { display: flex; justify-content: space-between; margin-bottom: 20px; }
                    .ds-stat { text-align: center; padding: 15px; background: #f8f9fa; border-radius: 4px; }
                    .ds-stat strong { display: block; font-size: 24px; color: #1d2327; }
                    .ds-quick-actions a { display: inline-block; margin-right: 10px; margin-bottom: 10px; }
                    @media (max-width: 782px) { .ds-location-dashboard { grid-template-columns: 1fr; } }
                </style>

                <div class="ds-dashboard-widget">
                    <h3>Quick Stats</h3>
                    <div class="ds-stats">
                        <div class="ds-stat">
                            <strong><?php echo $my_posts_count; ?></strong>
                            <span>My Posts</span>
                        </div>
                        <div class="ds-stat">
                            <strong><?php echo count($location_posts); ?></strong>
                            <span>Recent Posts</span>
                        </div>
                    </div>

                    <div class="ds-quick-actions">
                        <a href="<?php echo admin_url('post-new.php'); ?>" class="button button-primary">New Post</a>
                        <a href="<?php echo get_edit_post_link($user_location_id); ?>" class="button">Edit Location Page</a>
                        <a href="<?php echo get_permalink($user_location_id); ?>" class="button" target="_blank">View Location Page</a>
                    </div>
                </div>

                <div class="ds-dashboard-widget">
                    <h3>Recent Posts</h3>
                    <?php if (!empty($location_posts)) : ?>
                        <ul>
                            <?php foreach ($location_posts as $post) : setup_postdata($post); ?>
                                <li>
                                    <a href="<?php echo get_edit_post_link($post->ID); ?>">
                                        <?php echo esc_html(get_the_title($post)); ?>
                                    </a>
                                    <small style="color: #666;"> - <?php echo get_post_status($post->ID); ?></small>
                                </li>
                            <?php endforeach; wp_reset_postdata(); ?>
                        </ul>
                        <p><a href="<?php echo admin_url('edit.php'); ?>">View all posts &rarr;</a></p>
                    <?php else : ?>
                        <p>No posts yet. <a href="<?php echo admin_url('post-new.php'); ?>">Create your first post</a>!</p>
                    <?php endif; ?>
                </div>

                <div class="ds-dashboard-widget">
                    <h3>Location Information</h3>
                    <?php
                    $address = get_post_meta($user_location_id, '_ds_location_address', true);
                    $phone = get_post_meta($user_location_id, '_ds_location_phone', true);
                    $email = get_post_meta($user_location_id, '_ds_location_email', true);
                    ?>

                    <?php if ($address) : ?>
                        <p><strong>Address:</strong><br><?php echo nl2br(esc_html($address)); ?></p>
                    <?php endif; ?>

                    <?php if ($phone) : ?>
                        <p><strong>Phone:</strong> <?php echo esc_html($phone); ?></p>
                    <?php endif; ?>

                    <?php if ($email) : ?>
                        <p><strong>Email:</strong> <?php echo esc_html($email); ?></p>
                    <?php endif; ?>
                </div>

                <div class="ds-dashboard-widget">
                    <h3>Help & Resources</h3>
                    <ul>
                        <li><a href="#" onclick="alert('Help documentation coming soon!')">How to create posts</a></li>
                        <li><a href="#" onclick="alert('Help documentation coming soon!')">Using block patterns</a></li>
                        <li><a href="#" onclick="alert('Help documentation coming soon!')">Customizing your location page</a></li>
                        <li><a href="<?php echo admin_url('edit.php?post_type=ds_location'); ?>">Edit location details</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Customize admin bar for location managers
     */
    public function customize_admin_bar($wp_admin_bar) {
        $user = wp_get_current_user();
        if (!in_array('ds_location_manager', (array) $user->roles)) {
            return;
        }

        $user_location_id = get_user_meta($user->ID, 'ds_assigned_location', true);
        if ($user_location_id) {
            $location = get_post($user_location_id);
            if ($location) {
                $wp_admin_bar->add_node(array(
                    'id' => 'ds-location-quick',
                    'title' => 'My Location: ' . $location->post_title,
                    'href' => get_edit_post_link($user_location_id)
                ));

                $wp_admin_bar->add_node(array(
                    'id' => 'ds-view-location',
                    'parent' => 'ds-location-quick',
                    'title' => 'View Location Page',
                    'href' => get_permalink($user_location_id)
                ));

                $wp_admin_bar->add_node(array(
                    'id' => 'ds-edit-location',
                    'parent' => 'ds-location-quick',
                    'title' => 'Edit Location Page',
                    'href' => get_edit_post_link($user_location_id)
                ));
            }
        }
    }

    public function custom_admin_footer($text) {
        $user = wp_get_current_user();
        if (in_array('ds_location_manager', (array) $user->roles)) {
            return 'Managing your location content with DS Location Manager.';
        }
        return $text;
    }

    /**
     * Ensure author column appears for ds_location
     */
    public function location_posts_columns($columns) {
        if (isset($columns['author'])) {
            return $columns;
        }

        $new = array();
        foreach ($columns as $k => $v) {
            $new[$k] = $v;
            if ($k === 'title') {
                $new['author'] = __('Author');
            }
        }
        return $new;
    }

    /**
     * Make the author column sortable
     */
    public function location_sortable_columns($columns) {
        $columns['author'] = 'author';
        return $columns;
    }

    /**
     * Enhanced location assignment field
     */
    public function add_location_assignment_field($user) {
        if (!current_user_can('edit_users')) {
            return;
        }

        $assigned_location = get_user_meta($user->ID, 'ds_assigned_location', true);
        $locations = get_posts(array(
            'post_type' => 'ds_location',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC'
        ));

        ?>
        <h3>DS Location Assignment</h3>
        <table class="form-table" role="presentation">
            <tr>
                <th><label for="ds_assigned_location">Assigned Location</label></th>
                <td>
                    <select name="ds_assigned_location" id="ds_assigned_location">
                        <option value="">Select Location...</option>
                        <?php foreach ($locations as $location) : ?>
                            <option value="<?php echo $location->ID; ?>" <?php selected($assigned_location, $location->ID); ?>>
                                <?php echo esc_html($location->post_title); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">
                        Assign this user to manage a specific location. Location Managers can only edit their assigned location and create posts for that location.
                    </p>
                </td>
            </tr>
        </table>
        <?php
    }

    public function save_location_assignment_field($user_id) {
        if (!current_user_can('edit_users')) {
            return;
        }

        if (isset($_POST['ds_assigned_location'])) {
            $location_id = intval($_POST['ds_assigned_location']);
            update_user_meta($user_id, 'ds_assigned_location', $location_id);
        }
    }
}